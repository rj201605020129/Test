
#include <stdio.h>        
#include <stdlib.h>       
#include <string.h>       
#include <fcntl.h>

#include "cmd/cmd.h"


int main(int argc, char **argv)
{
	if(argc != 2)
	{
		printf("usage: check_extfs image\n");
		return 0;
	}
	char* imagepath = argv[1];
	
	if(!InitFS(imagepath))
	{

		return 0;
	}
	
	WaitCmd();


	ClearFS();
	return 1;

}
