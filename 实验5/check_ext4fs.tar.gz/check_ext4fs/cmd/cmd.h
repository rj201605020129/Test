#ifndef EXT_FS_CMD
#define EXT_FS_CMD

void PrintSBInfo();
int ExportFile(char* filepath);
void FileStat(char* filepath);

void PrintGroupsInfo();

void WaitCmd();

#endif



