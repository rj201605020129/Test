
#include <stdio.h>        
#include <stdlib.h>       
#include <string.h>       
#include <fcntl.h>
#include <time.h>
#include "../include/ext4_head.h"
#include "../fs/BlockIO.h"

#include "operate.h"

char g_pwd[2048];

char* FileType(int type)
{
	static char type_str[128];
	
	switch(type)
	{
		case EXT4_FT_REG_FILE:
			strcpy(type_str, "FILE");
			break;

		case EXT4_FT_DIR:
			strcpy(type_str, "DIR");
			break;

		case EXT4_FT_CHRDEV:
			strcpy(type_str, "CHRDEV");
			break;

		case EXT4_FT_BLKDEV:
			strcpy(type_str, "BLKDEV");
			break;

		case EXT4_FT_FIFO:
			strcpy(type_str, "FIFO");
			break;

		case EXT4_FT_SOCK:
			strcpy(type_str, "SOCK");
			break;

		case EXT4_FT_SYMLINK:
			strcpy(type_str, "LINK");
			break;

		default:
			strcpy(type_str, "UNKNOW");
			break;

	}

	return type_str;
}

char* FileMode(int mode)
{
	static char mode_str[32];

	memset(mode_str, '-', 10);

	if(S_ISLNK(mode))
	{
		mode_str[0] = 'l';
	}
	else if(S_ISREG(mode))
	{
		mode_str[0] = '-';
	}
	else if(S_ISDIR(mode))
	{
		mode_str[0] = 'd';
	}
	else if(S_ISBLK(mode))
	{
		mode_str[0] = 'b';
	}
	else if(S_ISCHR(mode))
	{
		mode_str[0] = 'c';
	}
	

	if(mode & S_IRUSR)
	{
		mode_str[1] = 'r';
	}

	if(mode & S_IWUSR)
	{
		mode_str[2] = 'w';
	}

	if(mode & S_IXUSR)
	{
		mode_str[3] = 'x';
	}

	if(mode & S_IRGRP)
	{
		mode_str[4] = 'r';
	}

	if(mode & S_IWGRP)
	{
		mode_str[5] = 'w';
	}

	if(mode & S_IXGRP)
	{
		mode_str[6] = 'x';
	}

	if(mode & S_IROTH)
	{
		mode_str[7] = 'r';
	}

	if(mode & S_IWOTH)
	{
		mode_str[8] = 'w';
	}

	if(mode & S_IXOTH)
	{
		mode_str[9] = 'x';
	}

		
	mode_str[10] = '\0';
	return mode_str;
}

void PrintSBInfo()
{
	ext4_super_block* sb = GetSuperBlock();
	printf("\n");
	printf("inode count: %d \n", sb->s_inodes_count);
	printf("block count: %d \n", sb->s_blocks_count_lo);
	printf("reserver block count: %d \n", sb->s_r_blocks_count_lo);
	printf("free block count: %d \n", sb->s_free_blocks_count_lo);
	printf("free inode count: %d \n", sb->s_free_inodes_count);
	printf("block size: %d \n", BlockSize());
	printf("block per group: %d \n", sb->s_blocks_per_group);
	printf("inode per group: %d \n", sb->s_inodes_per_group);	
	printf("block group count: %d \n", BlockGroupCount());
	printf("first data block: %d \n", sb->s_first_data_block);
	printf("reserved GDT blocks: %d \n", sb->s_reserved_gdt_blocks);
        time_t time = sb->s_mtime;
	char* timeStr = asctime(gmtime(&time));
	printf("mount time: %s", timeStr);
	
	time = sb->s_wtime;
	timeStr = asctime(gmtime(&time));
	printf("write time: %s", timeStr);	
	time = sb->s_lastcheck;
	timeStr = asctime(gmtime(&time));
	printf("last check time: %s", timeStr);

	printf("first inode: %d\n", sb->s_first_ino);
	printf("inode size: %d\n", sb->s_inode_size);
	printf("block group of super block: %d\n", sb->s_block_group_nr);
	char uuid[17];
	memcpy(uuid, sb->s_uuid, 16);
	uuid[16] = '\0';
	printf("uuid: %s\n", uuid);

	char volume_name[17];
	memcpy(volume_name, sb->s_volume_name, 16);
	volume_name[16] = '\0';
	printf("volume name: %s\n", volume_name);	
	
	char last_mount_dir[128];
	memcpy(last_mount_dir, sb->s_last_mounted, 64);
	last_mount_dir[64] = '\0';
	printf("last mounted dir: %s\n", last_mount_dir);	
	
	
	printf("%d percent used\n",(sb->s_blocks_count_lo - sb->s_free_blocks_count_lo) * 100 / 
		(sb->s_blocks_count_lo));
	printf("\n");
		
}

void PrintGroup(int index)
{
	ext4_group_desc* desc = GetGroupDesc(index);
	if(!desc)
	{
		printf("group desc %d not exist\n", index);
		return;
	}
	
	printf("group desc %d: \n", index);
	printf("  block bitmap: %d\n", desc->bg_block_bitmap_lo);
	printf("  inode bitmap: %d\n", desc->bg_inode_bitmap_lo);
	printf("  inode table: %d\n", desc->bg_inode_table_lo);		
	printf("  free block count: %d\n", desc->bg_free_blocks_count_lo);
	printf("  free inode count: %d\n", desc->bg_free_inodes_count_lo);
	printf("  used dir count: %d\n", desc->bg_used_dirs_count_lo);

}

void PrintGroupsInfo(char* param1, char* param2)
{
	int count = BlockGroupCount();
	int i = 0;

	int start = 0;
	int end = count - 1;

	if(param1 != NULL)
	{
		start = atoi(param1);
	}

	//��ӡ�ض�������
	if(param1 != NULL && param2 == NULL)
	{
		PrintGroup(start);
		return;
	}
	else if(param1 != NULL && param2 != NULL)
	{
		end = atoi(param2);
	}
	
	if(end <= start)
	{
		printf("end group index must be bigger than start group index \n");
		return;
	}

	if(start >= count - 1)
	{
		printf("start index too big \n");
		return;
	}

	if(end >= count)
	{
		printf("end index too big \n");
		return;
	}

	printf("\n");
	
	for(i = start; i <= end; i++)
	{
		PrintGroup(i);
	}

	printf("\n");

}

void PrintInode(char* param2)
{
	if(!param2)
	{
		printf("usage: info inode index\n");
		return;
	}

	int inode = atoi(param2);

	ext4_inode node;
	memset(&node, 0, sizeof(ext4_inode));
	if(!ReadInode(&node, inode))
	{
		printf("inode %d not exist !\n", inode);
		return ;
	}
	
	printf("inode %d:\n", inode);
	printf("  mode: %s\n", FileMode(node.i_mode));
	printf("  uid: %d\n", node.i_uid);
	printf("  gid: %d\n", node.i_gid);
	printf("  file size: %d\n", node.i_size_lo);
	printf("  link count: %d\n", node.i_links_count);
	printf("  blocks: %d\n", node.i_blocks_lo);
	printf("  file flag: %d\n", node.i_flags);
	
	time_t time = node.i_atime;
	char* timeStr = asctime(gmtime(&time));
	printf("  access time: %s", timeStr);

	time = node.i_ctime;
	timeStr = asctime(gmtime(&time));
	printf("  create time: %s", timeStr);

	time = node.i_mtime;
	timeStr = asctime(gmtime(&time));
	printf("  modify time: %s", timeStr);

	time = node.i_dtime;
	timeStr = asctime(gmtime(&time));
	printf("  delete time: %s", timeStr);

	printf("  first 8 block:\n");
	int i = 0;
	for(i = 0; i < 8; i++)
	{
		printf("    %d\n", node.i_block[i]);
	
	}
}

void PrintHelp()
{
	printf("\n    check_extfs version 0.1\n"
			"    This is a small program which can show base info of a ext4 file system,\n"
			"  such as print out super block, directory, file info, inode info. \n"
			"  Type `help name' to find out more about the cmd `name'.\n\n"
							);

	printf("  info [sb|superblock|groups|inode] \n");
	printf("  quit \n");
        printf("\n");
}

void PrintHelpInfo()
{
	printf("\n");
	printf("  print out base info of the file system:\n\n");

	printf("    info inode [num] : print out the inode \n");
	printf("    info groups : print out all the inode group desc \n");
	printf("    info groups [index]: print out the inode group desc of specify index\n");
	printf("    info groups [start_idx] [end_idx]: print out the inode group desc from start index to end index\n");
	printf("    info [sb|superblock] : print out superblock of the filesystem\n");


}
void GetAbsolutePath(char* pwd, char* inputPath)	//��ȡ����·��
{
	if(!inputPath)
	{
		strcpy(pwd, g_pwd);
		return;
	}

	if(inputPath[0] == '/')
	{
		strcpy(pwd, inputPath);
		return;
	}

	int len = strlen(inputPath);
	sprintf(pwd, "%s%s", g_pwd, inputPath);

	
}
