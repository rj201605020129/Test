
#include <stdio.h>        
#include <stdlib.h>       
#include <string.h>       
#include <fcntl.h>
#include <time.h>
#include "../include/ext4_head.h"
#include "../fs/BlockIO.h"
#include "operate.h"
#include "cmd.h"

#define MAX_PARAMS 40

static int s_params_count = 0;
static char s_params[MAX_PARAMS][1024];
extern char g_pwd[2048];

int ParseCmd(char* cmd)
{
	int len = strlen(cmd);
	int i = 0;
	s_params_count = 0;

	while(i < len)
	{
		char* p = &s_params[s_params_count][0];
		while(cmd[i] != ' ')
		{
			*p = cmd[i];
			i++;
			p++;
		}
		*p = '\0';

		while(cmd[i] == ' ')
		{
			i++;
		}
		
		s_params_count++;
		
	}

}

int StrCaseCmp(char* source, char* str)
{
	if(!source || !str)
	{
		return 0;
	}

	return strcasecmp(source, str) == 0;
}

int IsQuitCmd()
{
	if(StrCaseCmp(s_params[0], "quit"))
	{
		return 1;
	}

	if(StrCaseCmp(s_params[0], "exit"))
	{
		return 1;
	}

	if(StrCaseCmp(s_params[0], "q"))
	{
		return 1;
	}

	
	return 0;
}

void CmdInfo(char* param1, char* param2, char* param3, char* param4)
{
	if(StrCaseCmp(param1, "sb") || StrCaseCmp(param1, "superblock"))
	{
		PrintSBInfo();
	}
	else if(StrCaseCmp(param1, "groups"))
	{
		PrintGroupsInfo(param2, param3);
	}
	else if(StrCaseCmp(param1, "inode"))
	{
		PrintInode(param2);
	}
	else 
	{
		printf("invalid info cmd. for help pls type 'help info'\n");
	}
	
}

void CmdHelp(char* param1)
{
	if(!param1)
	{
		PrintHelp();
		return;
	}
        if(StrCaseCmp(param1,"info"))
	{
		PrintHelpInfo();
	}
	else
	{
		printf("%s is not a valid cmd\n", param1);
	}

}


void ExeCmd()
{
	char* params[MAX_PARAMS];
	memset(params, 0, sizeof(params));

	if(!s_params_count)
	{
		return;
	}
	
	int i = 0;
	for(i = 0; i < s_params_count; i++)
	{
		params[i] = s_params[i];
	}
	
	if(StrCaseCmp(s_params[0], "info"))
	{
		CmdInfo(params[1], params[2], params[3], params[4]);
	}
	else
        {
		printf("invaild cmd\n");
		printf("you can input: help\n\n");		
	}
	
}

void WaitCmd()
{
	char cmd[1024 * 16];
	strcpy(g_pwd, "/");
	
	printf("input cmd:\n\n");

	while(1)
	{
		printf("> ");
		gets(cmd);
		ParseCmd(cmd);	

		if(IsQuitCmd())
		{
			break;
		}

		ExeCmd();	
	}


}


